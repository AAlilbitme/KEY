# ITASEC'25 - Automated Analysis of Key Management Policies

Supplementary material for the ITASEC'25 submission:
```
M. Busi, R. Focardi, S. Gul and F.L. Luccio. Automated Analysis of Key Management Policies.
```

## File summary

The files in this folder contain the Tamarin models for various policies.
Please refer to the paper, especially to Table 1, for more information about the guarantees of each policy.

| Policy name | File name |
|---|---|
| Flat hierarchial policy, N=2 (Fig. 5) | Simple2.spthy |
| Flat hierarchial policy, N=3 | Simple3.spthy |
| Self-wrapping policy (Fig. 3) | Figure3.spthy |
| Flawed diamond-like hierarchical policy (Fig. 4) | Figure4.spthy |
| Secure diamond-like hierarchical policy | DiamondPolicy.spthy |
