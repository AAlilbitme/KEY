# Tamarin Models for the Provisioning Protocol

This repository contains the Tamarin models used to formally verify the
provisioning protocol presented in:

> *A Formally Verified Provisioning Protocol for Low Cost IoT Devices*

The models capture the protocol logic, compromise assumptions, and security
properties analyzed in the paper. Verification was performed using the
Tamarin Prover under the symbolic Dolev–Yao adversary model with support
for Diffie–Hellman reasoning.

---

## Overview of Models

The repository contains three `.spthy` files corresponding to
distinct threat scenarios.

### 1. `NoCompromise.spthy`

This model represents the baseline scenario with no compromise events.
In particular, it excludes:

- Long-term key compromise (`RevealLtk`)
- Ephemeral key compromise (`RevealEph`)
- TLS payload leakage (`TLSleak`)
- TLS integrity violations (`TLSinject`)

This model establishes:

- Executability of the protocol
- Session key secrecy
- Provisioning secrecy
- Authentication (device completion implies prior server provisioning)

This file corresponds to the core security guarantees stated in the paper
under explicitly defined trust assumptions.

---

### 2. `Device-compromise.spthy`

This model enables device long-term key compromise via:
RevealBk(Device)

Under this scenario, attack traces exist affecting:

- Session key secrecy
- Authentication and provisioning secrecy

The analysis shows that security properties can be restored by additionally
excluding:

- Device ephemeral compromise (`RevealEph(Device)`) for session key secrecy
- TLS integrity violations (`TLSinject`) for authentication and provisioning secrecy

This model illustrates the dependency between static key compromise,
ephemeral secrecy, and channel integrity.

---

### 3. `TLSleak.spthy`

This model enables leakage of the TLS payload used during manufacturing:
TLSleak(...)

Under this setting, authentication attacks become possible, including
cross-manufacturer interference scenarios.

Security properties can be recovered by excluding:

- TLS integrity violations (`TLSinject`)
- Device ephemeral compromise (`RevealEph(Device)`)

This model highlights the critical role of manufacturing-channel integrity
in the overall security guarantees.

---

## Server Compromise

Server long-term key compromise is modeled via:
RevealLtk(Server)

The analysis shows:

- No attacks arise solely from server compromise.
- Attacks become possible when both the server long-term key and the
  device long-term key are compromised, due to the static–static
  Diffie–Hellman component in the key schedule.

---

## Running the Verification

To execute automated proof search:
tamarin-prover --prove NoCompromise.spthy

For interactive exploration:
tamarin-prover interactive FileName.spthy

The `NoCompromise.spthy` model discharges all lemmas.
The other models generate counterexample traces under relaxed assumptions.

---

## Security Interpretation

The formal analysis establishes that the protocol achieves:

- Session key secrecy
- Provisioning secrecy
- Authentication

provided that:

1. Device ephemeral secrets remain confidential during execution,
2. TLS integrity is preserved during manufacturing,
3. Long-term keys are not compromised beyond the stated assumptions.

The models explicitly encode these assumptions, making the trust boundaries
and compromise conditions precise.

---

## Reproducibility

All verification results reported in the paper can be reproduced using the
provided `.spthy` files and a recent version of the Tamarin Prover
supporting Diffie–Hellman builtins.
